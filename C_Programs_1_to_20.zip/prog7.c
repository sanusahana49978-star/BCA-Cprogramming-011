#include <stdio.h>

int main()
{
    int units;
    float bill = 0;

    printf("Enter number of units: ");
    scanf("%d", &units);

    if (units <= 50)
        bill = units * 1.50;
    else if (units <= 150)
        bill = (50 * 1.50) + ((units - 50) * 2.50);
    else if (units <= 250)
        bill = (50 * 1.50) + (100 * 2.50) + ((units - 150) * 4.00);
    else
        bill = (50 * 1.50) + (100 * 2.50) +
               (100 * 4.00) + ((units - 250) * 6.00);

    bill = bill + 100;

    printf("Electricity Bill = Rs. %.2f", bill);

    return 0;
}
